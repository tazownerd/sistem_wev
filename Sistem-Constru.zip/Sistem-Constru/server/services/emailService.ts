import nodemailer from 'nodemailer';
import type { Budget, Contract } from '@shared/schema';

class EmailService {
  private transporter: nodemailer.Transporter;

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || 'smtp.gmail.com',
      port: parseInt(process.env.SMTP_PORT || '587'),
      secure: false,
      auth: {
        user: process.env.SMTP_USER || 'your-email@gmail.com',
        pass: process.env.SMTP_PASS || 'your-app-password',
      },
    });
  }

  async sendBudgetEmail(
    clientEmail: string,
    budget: Budget,
    pdfBuffer: Buffer
  ): Promise<void> {
    const mailOptions = {
      from: process.env.SMTP_USER || 'constructpro@empresa.com',
      to: clientEmail,
      subject: `Orçamento ${budget.id} - ConstructPro`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #1976D2; color: white; padding: 20px; text-align: center;">
            <h1>ConstructPro</h1>
            <p>Sistema de Gerenciamento de Construção</p>
          </div>
          
          <div style="padding: 20px; background-color: #f9f9f9;">
            <h2>Novo Orçamento</h2>
            <p>Prezado(a) cliente,</p>
            <p>Segue em anexo o orçamento solicitado:</p>
            
            <div style="background-color: white; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <h3>${budget.title}</h3>
              <p><strong>Valor Total:</strong> R$ ${Number(budget.totalValue).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
              <p><strong>Prazo Estimado:</strong> ${budget.estimatedDays} dias</p>
              <p><strong>Descrição:</strong> ${budget.description}</p>
            </div>
            
            <p>Este orçamento tem validade até ${budget.validUntil ? new Date(budget.validUntil).toLocaleDateString('pt-BR') : 'a definir'}.</p>
            
            <p>Para aceitar este orçamento ou esclarecer dúvidas, entre em contato conosco.</p>
            
            <p>Atenciosamente,<br>
            Equipe ConstructPro</p>
          </div>
          
          <div style="background-color: #424242; color: white; padding: 15px; text-align: center; font-size: 12px;">
            <p>Este é um email automático. Não responda.</p>
          </div>
        </div>
      `,
      attachments: [
        {
          filename: `orcamento-${budget.id}.pdf`,
          content: pdfBuffer,
          contentType: 'application/pdf',
        },
      ],
    };

    await this.transporter.sendMail(mailOptions);
  }

  async sendContractEmail(
    clientEmail: string,
    contract: Contract,
    pdfBuffer: Buffer
  ): Promise<void> {
    const mailOptions = {
      from: process.env.SMTP_USER || 'constructpro@empresa.com',
      to: clientEmail,
      subject: `Contrato ${contract.contractNumber} - ConstructPro`,
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <div style="background-color: #1976D2; color: white; padding: 20px; text-align: center;">
            <h1>ConstructPro</h1>
            <p>Sistema de Gerenciamento de Construção</p>
          </div>
          
          <div style="padding: 20px; background-color: #f9f9f9;">
            <h2>Contrato de Prestação de Serviços</h2>
            <p>Prezado(a) cliente,</p>
            <p>Segue em anexo o contrato de prestação de serviços:</p>
            
            <div style="background-color: white; padding: 15px; border-radius: 5px; margin: 20px 0;">
              <h3>${contract.title}</h3>
              <p><strong>Número do Contrato:</strong> ${contract.contractNumber}</p>
              <p><strong>Valor Total:</strong> R$ ${Number(contract.totalValue).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</p>
              <p><strong>Data de Início:</strong> ${contract.startDate ? new Date(contract.startDate).toLocaleDateString('pt-BR') : 'A definir'}</p>
              <p><strong>Data de Término:</strong> ${contract.endDate ? new Date(contract.endDate).toLocaleDateString('pt-BR') : 'A definir'}</p>
              <p><strong>Descrição:</strong> ${contract.description}</p>
            </div>
            
            <p>Por favor, leia atentamente todos os termos do contrato em anexo.</p>
            <p>Para assinatura ou esclarecimentos, entre em contato conosco.</p>
            
            <p>Atenciosamente,<br>
            Equipe ConstructPro</p>
          </div>
          
          <div style="background-color: #424242; color: white; padding: 15px; text-align: center; font-size: 12px;">
            <p>Este é um email automático. Não responda.</p>
          </div>
        </div>
      `,
      attachments: [
        {
          filename: `contrato-${contract.contractNumber}.pdf`,
          content: pdfBuffer,
          contentType: 'application/pdf',
        },
      ],
    };

    await this.transporter.sendMail(mailOptions);
  }
}

export const emailService = new EmailService();
