import PDFDocument from 'pdfkit';
import type { Budget, Contract, Client } from '@shared/schema';

class PDFService {
  async generateBudgetPDF(budget: Budget, client: Client | null): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const doc = new PDFDocument();
      const buffers: Buffer[] = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(buffers);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      // Header
      doc.fontSize(20).text('ConstructPro', 50, 50);
      doc.fontSize(12).text('Sistema de Gerenciamento de Construção', 50, 75);
      doc.moveTo(50, 100).lineTo(550, 100).stroke();

      // Title
      doc.fontSize(16).text('ORÇAMENTO', 50, 120);
      doc.fontSize(12).text(`Orçamento Nº: ${budget.id}`, 50, 145);
      doc.text(`Data: ${new Date(budget.createdAt!).toLocaleDateString('pt-BR')}`, 50, 160);

      // Client info
      if (client) {
        doc.text('DADOS DO CLIENTE', 50, 190);
        doc.text(`Nome: ${client.name}`, 50, 210);
        doc.text(`Email: ${client.email || 'N/A'}`, 50, 225);
        doc.text(`Telefone: ${client.phone || 'N/A'}`, 50, 240);
        doc.text(`Endereço: ${client.address || 'N/A'}`, 50, 255);
      }

      // Budget details
      doc.text('DETALHES DO ORÇAMENTO', 50, 290);
      doc.text(`Título: ${budget.title}`, 50, 310);
      doc.text(`Descrição: ${budget.description || 'N/A'}`, 50, 325);
      doc.text(`Prazo Estimado: ${budget.estimatedDays} dias`, 50, 340);
      doc.text(`Valor Total: R$ ${Number(budget.totalValue).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 50, 355);

      // Items
      if (budget.items && Array.isArray(budget.items)) {
        doc.text('ITENS DO ORÇAMENTO', 50, 390);
        let yPosition = 410;
        
        (budget.items as any[]).forEach((item, index) => {
          doc.text(`${index + 1}. ${item.description || 'Item'}`, 50, yPosition);
          doc.text(`Qtd: ${item.quantity || 1}`, 300, yPosition);
          doc.text(`Valor: R$ ${Number(item.value || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 400, yPosition);
          yPosition += 20;
        });
      }

      // Terms
      doc.text('OBSERVAÇÕES', 50, yPosition + 30);
      doc.text('- Este orçamento tem validade de 30 dias.', 50, yPosition + 50);
      doc.text('- Os valores podem sofrer alterações mediante mudanças no escopo.', 50, yPosition + 65);
      doc.text('- Material e mão de obra inclusos conforme especificado.', 50, yPosition + 80);

      // Footer
      doc.text('ConstructPro - Construção Civil', 50, 750);
      doc.text('Email: contato@constructpro.com | Telefone: (11) 9999-9999', 50, 765);

      doc.end();
    });
  }

  async generateContractPDF(contract: Contract, client: Client | null): Promise<Buffer> {
    return new Promise((resolve, reject) => {
      const doc = new PDFDocument();
      const buffers: Buffer[] = [];

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        const pdfBuffer = Buffer.concat(buffers);
        resolve(pdfBuffer);
      });
      doc.on('error', reject);

      // Header
      doc.fontSize(20).text('ConstructPro', 50, 50);
      doc.fontSize(12).text('Sistema de Gerenciamento de Construção', 50, 75);
      doc.moveTo(50, 100).lineTo(550, 100).stroke();

      // Title
      doc.fontSize(16).text('CONTRATO DE PRESTAÇÃO DE SERVIÇOS', 50, 120);
      doc.fontSize(12).text(`Contrato Nº: ${contract.contractNumber}`, 50, 145);
      doc.text(`Data: ${new Date(contract.createdAt!).toLocaleDateString('pt-BR')}`, 50, 160);

      // Parties
      doc.text('CONTRATANTE:', 50, 190);
      if (client) {
        doc.text(`Nome: ${client.name}`, 50, 210);
        doc.text(`Email: ${client.email || 'N/A'}`, 50, 225);
        doc.text(`Telefone: ${client.phone || 'N/A'}`, 50, 240);
        doc.text(`Endereço: ${client.address || 'N/A'}`, 50, 255);
      }

      doc.text('CONTRATADA:', 50, 290);
      doc.text('ConstructPro Construção Civil Ltda.', 50, 310);
      doc.text('CNPJ: 12.345.678/0001-90', 50, 325);
      doc.text('Endereço: Rua das Construções, 123, São Paulo/SP', 50, 340);

      // Contract details
      doc.text('OBJETO DO CONTRATO:', 50, 375);
      doc.text(`Título: ${contract.title}`, 50, 395);
      doc.text(`Descrição: ${contract.description || 'N/A'}`, 50, 410);
      doc.text(`Valor Total: R$ ${Number(contract.totalValue).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, 50, 425);
      doc.text(`Data de Início: ${contract.startDate ? new Date(contract.startDate).toLocaleDateString('pt-BR') : 'A definir'}`, 50, 440);
      doc.text(`Data de Término: ${contract.endDate ? new Date(contract.endDate).toLocaleDateString('pt-BR') : 'A definir'}`, 50, 455);

      // Terms
      doc.text('CLÁUSULAS:', 50, 490);
      doc.text('1. A CONTRATADA se obriga a executar os serviços conforme especificado.', 50, 510);
      doc.text('2. O pagamento será realizado conforme cronograma estabelecido.', 50, 525);
      doc.text('3. Qualquer alteração deve ser acordada por escrito.', 50, 540);
      doc.text('4. Este contrato é regido pelas leis brasileiras.', 50, 555);

      if (contract.terms) {
        doc.text('TERMOS ADICIONAIS:', 50, 580);
        doc.text(contract.terms, 50, 600, { width: 500 });
      }

      // Signatures
      doc.text('ASSINATURAS:', 50, 680);
      doc.text('_________________________', 50, 720);
      doc.text('CONTRATANTE', 50, 735);
      doc.text('_________________________', 300, 720);
      doc.text('CONTRATADA', 300, 735);

      doc.end();
    });
  }
}

export const pdfService = new PDFService();
