import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TemplateGridProps {
  templates: any[];
  isLoading: boolean;
  onEdit: (template: any) => void;
}

export function TemplateGrid({ templates, isLoading, onEdit }: TemplateGridProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/templates/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/templates"] });
      toast({
        title: "Template excluído",
        description: "Template excluído com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <p>Carregando templates...</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {templates.map((template) => (
        <Card key={template.id} className="relative">
          <CardHeader className="pb-3">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <CardTitle className="text-lg">{template.name}</CardTitle>
                <p className="text-sm text-gray-600 mt-1">{template.description}</p>
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onEdit(template)}
                  title="Editar"
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteMutation.mutate(template.id)}
                  disabled={deleteMutation.isPending}
                  title="Excluir"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <Badge variant="outline">{template.serviceType}</Badge>
            </div>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Valor Base:</span>
                <span className="font-medium">{formatCurrency(Number(template.baseValue))}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Prazo:</span>
                <span className="font-medium">{template.estimatedDays} dias</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Última alteração:</span>
                <span className="font-medium">{formatDate(template.updatedAt || template.createdAt)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Itens:</span>
                <span className="font-medium">{template.items?.length || 0}</span>
              </div>
            </div>

            <div className="pt-4 border-t">
              <Button className="w-full btn-secondary">
                Usar Template
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
      
      {templates.length === 0 && (
        <div className="col-span-full text-center text-gray-500 py-12">
          <p>Nenhum template encontrado</p>
          <p className="text-sm mt-1">Crie seu primeiro template para começar</p>
        </div>
      )}
    </div>
  );
}
