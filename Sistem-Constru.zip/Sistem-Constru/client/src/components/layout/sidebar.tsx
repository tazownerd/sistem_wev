import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { 
  TrendingUp, 
  Calculator, 
  FileText, 
  Banknote, 
  ClipboardList, 
  Users 
} from "lucide-react";

const navigation = [
  { name: "Dashboard", href: "/", icon: TrendingUp },
  { name: "Orçamentos", href: "/budgets", icon: Calculator },
  { name: "Contratos", href: "/contracts", icon: FileText },
  { name: "Fluxo de Caixa", href: "/cashflow", icon: Banknote },
  { name: "Templates", href: "/templates", icon: ClipboardList },
  { name: "Clientes", href: "/clients", icon: Users },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-64 bg-white shadow-sm min-h-screen border-r border-gray-200">
      <nav className="p-4">
        <ul className="space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;

            return (
              <li key={item.name}>
                <Link href={item.href}>
                  <a className={cn("nav-link", isActive && "active")}>
                    <Icon className="h-5 w-5" />
                    <span>{item.name}</span>
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </aside>
  );
}
