import * as React from "react"
import { useToast } from "@/hooks/use-toast"
import { SimpleToast } from "@/components/ui/simple-toast"

export function SimpleToaster() {
  const { toasts, dismiss } = useToast()

  return (
    <div className="fixed top-4 right-4 z-50 space-y-2">
      {toasts.map((toast) => (
        <SimpleToast
          key={toast.id}
          title={toast.title}
          description={toast.description}
          variant={toast.variant}
          onClose={() => dismiss(toast.id)}
        />
      ))}
    </div>
  )
}