import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Edit, Trash2, ArrowUp, ArrowDown } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface TransactionTableProps {
  transactions: any[];
  isLoading: boolean;
  onEdit: (transaction: any) => void;
}

export function TransactionTable({ transactions, isLoading, onEdit }: TransactionTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/summary"] });
      toast({
        title: "Transação excluída",
        description: "Transação excluída com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const getTypeBadge = (type: string) => {
    if (type === 'income') {
      return (
        <Badge variant="secondary" className="status-approved">
          <ArrowUp className="h-3 w-3 mr-1" />
          Entrada
        </Badge>
      );
    } else {
      return (
        <Badge variant="secondary" className="status-rejected">
          <ArrowDown className="h-3 w-3 mr-1" />
          Saída
        </Badge>
      );
    }
  };

  const getAmountClass = (type: string) => {
    return type === 'income' ? 'income-text' : 'expense-text';
  };

  const formatAmount = (amount: number, type: string) => {
    const formatted = formatCurrency(amount);
    return type === 'income' ? `+ ${formatted}` : `- ${formatted}`;
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <p>Carregando transações...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Data</TableHead>
            <TableHead>Descrição</TableHead>
            <TableHead>Tipo</TableHead>
            <TableHead>Valor</TableHead>
            <TableHead>Categoria</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {transactions.map((transaction) => (
            <TableRow key={transaction.id}>
              <TableCell>{formatDate(transaction.date)}</TableCell>
              <TableCell className="font-medium">{transaction.description}</TableCell>
              <TableCell>{getTypeBadge(transaction.type)}</TableCell>
              <TableCell>
                <span className={getAmountClass(transaction.type)}>
                  {formatAmount(Number(transaction.amount), transaction.type)}
                </span>
              </TableCell>
              <TableCell>{transaction.category}</TableCell>
              <TableCell>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(transaction)}
                    title="Editar"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteMutation.mutate(transaction.id)}
                    disabled={deleteMutation.isPending}
                    title="Excluir"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
      {transactions.length === 0 && (
        <div className="p-6 text-center text-gray-500">
          Nenhuma transação encontrada
        </div>
      )}
    </div>
  );
}
