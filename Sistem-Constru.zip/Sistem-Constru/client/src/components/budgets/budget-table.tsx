import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Eye, Edit, Share, Trash2, Download, MessageCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface BudgetTableProps {
  budgets: any[];
  isLoading: boolean;
  onEdit: (budget: any) => void;
}

export function BudgetTable({ budgets, isLoading, onEdit }: BudgetTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/budgets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/budgets"] });
      toast({
        title: "Orçamento excluído",
        description: "Orçamento excluído com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sendEmailMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/budgets/${id}/send-email`);
    },
    onSuccess: () => {
      toast({
        title: "Email enviado",
        description: "Orçamento enviado por email com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sendWhatsAppMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/budgets/${id}/send-whatsapp`);
    },
    onSuccess: () => {
      toast({
        title: "WhatsApp enviado",
        description: "Orçamento enviado por WhatsApp com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDownloadPDF = (budgetId: number) => {
    window.open(`/api/budgets/${budgetId}/pdf`, '_blank');
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="secondary" className="status-pending">Pendente</Badge>;
      case 'approved':
        return <Badge variant="secondary" className="status-approved">Aprovado</Badge>;
      case 'rejected':
        return <Badge variant="secondary" className="status-rejected">Rejeitado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <p>Carregando orçamentos...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Título</TableHead>
            <TableHead>Cliente</TableHead>
            <TableHead>Valor</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Data</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {budgets.map((budget) => (
            <TableRow key={budget.id}>
              <TableCell>#{budget.id}</TableCell>
              <TableCell className="font-medium">{budget.title}</TableCell>
              <TableCell>{budget.client?.name || 'N/A'}</TableCell>
              <TableCell>{formatCurrency(Number(budget.totalValue))}</TableCell>
              <TableCell>{getStatusBadge(budget.status)}</TableCell>
              <TableCell>{formatDate(budget.createdAt)}</TableCell>
              <TableCell>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDownloadPDF(budget.id)}
                    title="Baixar PDF"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(budget)}
                    title="Editar"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => sendEmailMutation.mutate(budget.id)}
                    disabled={sendEmailMutation.isPending}
                    title="Enviar por Email"
                  >
                    <Share className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => sendWhatsAppMutation.mutate(budget.id)}
                    disabled={sendWhatsAppMutation.isPending}
                    title="Enviar por WhatsApp"
                  >
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteMutation.mutate(budget.id)}
                    disabled={deleteMutation.isPending}
                    title="Excluir"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
      {budgets.length === 0 && (
        <div className="p-6 text-center text-gray-500">
          Nenhum orçamento encontrado
        </div>
      )}
    </div>
  );
}
