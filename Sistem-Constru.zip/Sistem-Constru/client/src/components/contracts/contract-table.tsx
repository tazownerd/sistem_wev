import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Edit, Share, Trash2, Download, MessageCircle } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ContractTableProps {
  contracts: any[];
  isLoading: boolean;
  onEdit: (contract: any) => void;
}

export function ContractTable({ contracts, isLoading, onEdit }: ContractTableProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("DELETE", `/api/contracts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      toast({
        title: "Contrato excluído",
        description: "Contrato excluído com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sendEmailMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/contracts/${id}/send-email`);
    },
    onSuccess: () => {
      toast({
        title: "Email enviado",
        description: "Contrato enviado por email com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const sendWhatsAppMutation = useMutation({
    mutationFn: async (id: number) => {
      return await apiRequest("POST", `/api/contracts/${id}/send-whatsapp`);
    },
    onSuccess: () => {
      toast({
        title: "WhatsApp enviado",
        description: "Contrato enviado por WhatsApp com sucesso",
      });
    },
    onError: (error) => {
      toast({
        title: "Erro",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleDownloadPDF = (contractId: number) => {
    window.open(`/api/contracts/${contractId}/pdf`, '_blank');
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="secondary" className="status-active">Ativo</Badge>;
      case 'completed':
        return <Badge variant="secondary" className="status-completed">Concluído</Badge>;
      case 'cancelled':
        return <Badge variant="secondary" className="status-cancelled">Cancelado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 text-center">
        <p>Carregando contratos...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Número</TableHead>
            <TableHead>Título</TableHead>
            <TableHead>Cliente</TableHead>
            <TableHead>Valor</TableHead>
            <TableHead>Início</TableHead>
            <TableHead>Prazo</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Ações</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {contracts.map((contract) => (
            <TableRow key={contract.id}>
              <TableCell className="font-medium">{contract.contractNumber}</TableCell>
              <TableCell>{contract.title}</TableCell>
              <TableCell>{contract.client?.name || 'N/A'}</TableCell>
              <TableCell>{formatCurrency(Number(contract.totalValue))}</TableCell>
              <TableCell>
                {contract.startDate ? formatDate(contract.startDate) : 'A definir'}
              </TableCell>
              <TableCell>
                {contract.endDate ? formatDate(contract.endDate) : 'A definir'}
              </TableCell>
              <TableCell>{getStatusBadge(contract.status)}</TableCell>
              <TableCell>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDownloadPDF(contract.id)}
                    title="Baixar PDF"
                  >
                    <Download className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(contract)}
                    title="Editar"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => sendEmailMutation.mutate(contract.id)}
                    disabled={sendEmailMutation.isPending}
                    title="Enviar por Email"
                  >
                    <Share className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => sendWhatsAppMutation.mutate(contract.id)}
                    disabled={sendWhatsAppMutation.isPending}
                    title="Enviar por WhatsApp"
                  >
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteMutation.mutate(contract.id)}
                    disabled={deleteMutation.isPending}
                    title="Excluir"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      
      {contracts.length === 0 && (
        <div className="p-6 text-center text-gray-500">
          Nenhum contrato encontrado
        </div>
      )}
    </div>
  );
}
