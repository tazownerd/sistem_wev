import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { SimpleToaster } from "@/components/ui/simple-toaster";
import { useAuth } from "@/hooks/useAuth";
import SimpleLanding from "@/pages/simple-landing";
import SimpleHome from "@/pages/simple-home";
import SimpleBudgets from "@/pages/simple-budgets";
import SimpleClients from "@/pages/simple-clients";
import SimpleCashflow from "@/pages/simple-cashflow";
import SimpleContracts from "@/pages/simple-contracts";
import SimpleTemplates from "@/pages/simple-templates";
import AdminUsers from "@/pages/admin-users";
import NotFound from "@/pages/not-found";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading || !isAuthenticated) {
    return (
      <Switch>
        <Route path="/" component={SimpleLanding} />
        <Route component={SimpleLanding} />
      </Switch>
    );
  }

  return (
    <Switch>
      <Route path="/" component={SimpleHome} />
      <Route path="/budgets" component={SimpleBudgets} />
      <Route path="/clients" component={SimpleClients} />
      <Route path="/cashflow" component={SimpleCashflow} />
      <Route path="/contracts" component={SimpleContracts} />
      <Route path="/templates" component={SimpleTemplates} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div>
        <SimpleToaster />
        <Router />
      </div>
    </QueryClientProvider>
  );
}

export default App;
