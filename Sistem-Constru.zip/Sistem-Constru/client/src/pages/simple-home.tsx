import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

export default function SimpleHome() {
  const { data: user } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">ConstructPro</h1>
            </div>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">
                Bem-vindo, {user?.firstName || 'Usuário'}
              </span>
              <button
                onClick={handleLogout}
                className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
              >
                Sair
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Painel de Controle
          </h2>
          <p className="text-gray-600">
            Gerencie sua empresa de construção civil de forma eficiente
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Link href="/budgets">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-blue-500 rounded-md flex items-center justify-center">
                    <span className="text-white font-bold">$</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    Orçamentos
                  </h3>
                  <p className="text-gray-500">
                    Criar e gerenciar orçamentos
                  </p>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/contracts">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-green-500 rounded-md flex items-center justify-center">
                    <span className="text-white font-bold">📄</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    Contratos
                  </h3>
                  <p className="text-gray-500">
                    Gerenciar contratos de serviços
                  </p>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/cashflow">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-purple-500 rounded-md flex items-center justify-center">
                    <span className="text-white font-bold">💰</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    Fluxo de Caixa
                  </h3>
                  <p className="text-gray-500">
                    Controlar receitas e despesas
                  </p>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/clients">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-yellow-500 rounded-md flex items-center justify-center">
                    <span className="text-white font-bold">👥</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    Clientes
                  </h3>
                  <p className="text-gray-500">
                    Gerenciar informações dos clientes
                  </p>
                </div>
              </div>
            </div>
          </Link>

          <Link href="/templates">
            <div className="bg-white rounded-lg shadow p-6 hover:shadow-md transition-shadow cursor-pointer">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className="w-8 h-8 bg-indigo-500 rounded-md flex items-center justify-center">
                    <span className="text-white font-bold">📋</span>
                  </div>
                </div>
                <div className="ml-4">
                  <h3 className="text-lg font-medium text-gray-900">
                    Templates
                  </h3>
                  <p className="text-gray-500">
                    Modelos de orçamentos
                  </p>
                </div>
              </div>
            </div>
          </Link>
        </div>
        
        {/* Admin Panel - Only visible for admin users */}
        {user?.role === 'admin' && (
          <div className="mt-8">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Painel Administrativo</h2>
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-medium text-purple-900">Gestão de Usuários</h3>
                  <p className="text-purple-700 mt-1">Gerencie usuários e permissões do sistema</p>
                </div>
                <Link 
                  href="/admin/users"
                  className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-md text-sm font-medium"
                >
                  Gerenciar Usuários
                </Link>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}