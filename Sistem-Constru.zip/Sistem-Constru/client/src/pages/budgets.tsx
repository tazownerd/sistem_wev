import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { BudgetForm } from "@/components/budgets/budget-form";
import { BudgetTable } from "@/components/budgets/budget-table";

export default function Budgets() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingBudget, setEditingBudget] = useState<any>(null);

  const { data: budgets, isLoading } = useQuery({
    queryKey: ["/api/budgets"],
  });

  const handleEdit = (budget: any) => {
    setEditingBudget(budget);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingBudget(null);
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Orçamentos</h2>
          <p className="text-gray-600 mt-2">Gerencie seus orçamentos e propostas</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          <span>Novo Orçamento</span>
        </Button>
      </div>

      <Card>
        <CardHeader className="border-b">
          <CardTitle>Lista de Orçamentos</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <BudgetTable 
            budgets={budgets || []} 
            isLoading={isLoading}
            onEdit={handleEdit}
          />
        </CardContent>
      </Card>

      {isFormOpen && (
        <BudgetForm 
          budget={editingBudget}
          onClose={handleCloseForm}
        />
      )}
    </div>
  );
}
