import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, ArrowUp, ArrowDown, Wallet } from "lucide-react";
import { TransactionForm } from "@/components/cashflow/transaction-form";
import { TransactionTable } from "@/components/cashflow/transaction-table";

export default function Cashflow() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<any>(null);

  const { data: transactions, isLoading } = useQuery({
    queryKey: ["/api/transactions"],
  });

  const { data: summary } = useQuery({
    queryKey: ["/api/transactions/summary"],
  });

  const handleEdit = (transaction: any) => {
    setEditingTransaction(transaction);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingTransaction(null);
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-gray-900">Fluxo de Caixa</h2>
        <p className="text-gray-600 mt-2">Controle financeiro da empresa</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Entradas</p>
                <p className="text-2xl font-bold text-success">{formatCurrency(summary?.totalIncome || 0)}</p>
              </div>
              <div className="stat-icon bg-success/10">
                <ArrowUp className="h-6 w-6 text-success" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Saídas</p>
                <p className="text-2xl font-bold text-destructive">{formatCurrency(summary?.totalExpenses || 0)}</p>
              </div>
              <div className="stat-icon bg-destructive/10">
                <ArrowDown className="h-6 w-6 text-destructive" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Saldo</p>
                <p className="text-2xl font-bold text-primary">{formatCurrency(summary?.balance || 0)}</p>
              </div>
              <div className="stat-icon bg-primary/10">
                <Wallet className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="border-b flex flex-row items-center justify-between">
          <CardTitle>Movimentações</CardTitle>
          <Button onClick={() => setIsFormOpen(true)} className="btn-primary">
            <Plus className="h-4 w-4" />
            <span>Nova Movimentação</span>
          </Button>
        </CardHeader>
        <CardContent className="p-0">
          <TransactionTable 
            transactions={transactions || []} 
            isLoading={isLoading}
            onEdit={handleEdit}
          />
        </CardContent>
      </Card>

      {isFormOpen && (
        <TransactionForm 
          transaction={editingTransaction}
          onClose={handleCloseForm}
        />
      )}
    </div>
  );
}
