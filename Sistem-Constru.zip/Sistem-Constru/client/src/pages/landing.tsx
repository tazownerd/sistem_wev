import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { HardHat, Calculator, FileText, TrendingUp, Users, Shield } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary to-blue-800">
      <div className="min-h-screen flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-primary text-white rounded-full mb-4">
                <HardHat className="h-8 w-8" />
              </div>
              <h1 className="text-3xl font-bold text-gray-900">ConstructPro</h1>
              <p className="text-gray-600 mt-2">Sistema de Gerenciamento</p>
            </div>

            <div className="space-y-4 mb-8">
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Calculator className="h-4 w-4 text-primary" />
                <span>Gerenciamento de Orçamentos</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <FileText className="h-4 w-4 text-primary" />
                <span>Contratos de Prestação de Serviços</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <TrendingUp className="h-4 w-4 text-primary" />
                <span>Controle de Fluxo de Caixa</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Users className="h-4 w-4 text-primary" />
                <span>Gerenciamento de Clientes</span>
              </div>
              <div className="flex items-center space-x-3 text-sm text-gray-600">
                <Shield className="h-4 w-4 text-primary" />
                <span>Níveis de Acesso Seguros</span>
              </div>
            </div>

            <Button onClick={handleLogin} className="w-full btn-primary">
              Entrar no Sistema
            </Button>

            <div className="mt-6 text-center text-sm text-gray-600">
              <p>Sistema profissional para empresas de construção civil</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
