import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { ContractForm } from "@/components/contracts/contract-form";
import { ContractTable } from "@/components/contracts/contract-table";

export default function Contracts() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingContract, setEditingContract] = useState<any>(null);

  const { data: contracts, isLoading } = useQuery({
    queryKey: ["/api/contracts"],
  });

  const handleEdit = (contract: any) => {
    setEditingContract(contract);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingContract(null);
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Contratos</h2>
          <p className="text-gray-600 mt-2">Gerencie contratos de prestação de serviços</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          <span>Novo Contrato</span>
        </Button>
      </div>

      <Card>
        <CardHeader className="border-b">
          <CardTitle>Contratos</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ContractTable 
            contracts={contracts || []} 
            isLoading={isLoading}
            onEdit={handleEdit}
          />
        </CardContent>
      </Card>

      {isFormOpen && (
        <ContractForm 
          contract={editingContract}
          onClose={handleCloseForm}
        />
      )}
    </div>
  );
}
