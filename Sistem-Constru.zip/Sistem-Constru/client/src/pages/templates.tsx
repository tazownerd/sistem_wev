import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { TemplateForm } from "@/components/templates/template-form";
import { TemplateGrid } from "@/components/templates/template-grid";

export default function Templates() {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<any>(null);

  const { data: templates, isLoading } = useQuery({
    queryKey: ["/api/templates"],
  });

  const handleEdit = (template: any) => {
    setEditingTemplate(template);
    setIsFormOpen(true);
  };

  const handleCloseForm = () => {
    setIsFormOpen(false);
    setEditingTemplate(null);
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900">Templates</h2>
          <p className="text-gray-600 mt-2">Gerencie templates de orçamentos</p>
        </div>
        <Button onClick={() => setIsFormOpen(true)} className="btn-primary">
          <Plus className="h-4 w-4" />
          <span>Novo Template</span>
        </Button>
      </div>

      <TemplateGrid 
        templates={templates || []} 
        isLoading={isLoading}
        onEdit={handleEdit}
      />

      {isFormOpen && (
        <TemplateForm 
          template={editingTemplate}
          onClose={handleCloseForm}
        />
      )}
    </div>
  );
}
