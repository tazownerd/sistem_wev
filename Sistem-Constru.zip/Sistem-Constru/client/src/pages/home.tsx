import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator, FileText, DollarSign, Clock, ArrowUp, ArrowDown, Wallet } from "lucide-react";

export default function Home() {
  const { data: budgets } = useQuery({
    queryKey: ["/api/budgets"],
  });

  const { data: contracts } = useQuery({
    queryKey: ["/api/contracts"],
  });

  const { data: cashFlowSummary } = useQuery({
    queryKey: ["/api/transactions/summary"],
  });

  const { data: transactions } = useQuery({
    queryKey: ["/api/transactions"],
  });

  const pendingBudgets = budgets?.filter((b: any) => b.status === 'pending')?.length || 0;
  const activeContracts = contracts?.filter((c: any) => c.status === 'active')?.length || 0;
  const recentTransactions = transactions?.slice(0, 5) || [];

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL',
    }).format(value);
  };

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString('pt-BR');
  };

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-3xl font-bold text-gray-900">Dashboard</h2>
        <p className="text-gray-600 mt-2">Visão geral do seu negócio</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="stat-icon bg-primary/10">
                <Calculator className="h-6 w-6 text-primary" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Orçamentos</p>
                <p className="text-2xl font-bold text-gray-900">{budgets?.length || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="stat-icon bg-success/10">
                <FileText className="h-6 w-6 text-success" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Contratos Ativos</p>
                <p className="text-2xl font-bold text-gray-900">{activeContracts}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="stat-icon bg-accent/10">
                <DollarSign className="h-6 w-6 text-accent" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Saldo</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(cashFlowSummary?.balance || 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="stat-icon bg-warning/10">
                <Clock className="h-6 w-6 text-warning" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Pendentes</p>
                <p className="text-2xl font-bold text-gray-900">{pendingBudgets}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="border-b">
            <CardTitle>Orçamentos Recentes</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {budgets?.slice(0, 5).map((budget: any) => (
                <div key={budget.id} className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{budget.title}</p>
                    <p className="text-sm text-gray-600">{budget.description}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-gray-900">{formatCurrency(Number(budget.totalValue))}</p>
                    <span className={`status-badge status-${budget.status}`}>
                      {budget.status === 'pending' && 'Pendente'}
                      {budget.status === 'approved' && 'Aprovado'}
                      {budget.status === 'rejected' && 'Rejeitado'}
                    </span>
                  </div>
                </div>
              ))}
              {(!budgets || budgets.length === 0) && (
                <p className="text-gray-500 text-center py-4">Nenhum orçamento encontrado</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="border-b">
            <CardTitle>Fluxo de Caixa</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <ArrowUp className="h-4 w-4 text-success" />
                  <span className="text-sm text-gray-600">Entradas</span>
                </div>
                <span className="income-text">{formatCurrency(cashFlowSummary?.totalIncome || 0)}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <ArrowDown className="h-4 w-4 text-destructive" />
                  <span className="text-sm text-gray-600">Saídas</span>
                </div>
                <span className="expense-text">- {formatCurrency(cashFlowSummary?.totalExpenses || 0)}</span>
              </div>
              <div className="border-t pt-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <Wallet className="h-4 w-4 text-primary" />
                    <span className="font-medium text-gray-900">Saldo</span>
                  </div>
                  <span className="balance-text">{formatCurrency(cashFlowSummary?.balance || 0)}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
