import * as React from "react"

interface ToastMessage {
  id: string
  title?: string
  description?: string
  variant?: "default" | "destructive"
}

interface ToastState {
  toasts: ToastMessage[]
}

const useToast = () => {
  const [state, setState] = React.useState<ToastState>({ toasts: [] })

  const toast = React.useCallback(({ title, description, variant = "default" }: Omit<ToastMessage, "id">) => {
    const id = Math.random().toString(36).substr(2, 9)
    const newToast: ToastMessage = { id, title, description, variant }
    
    setState(prev => ({ toasts: [...prev.toasts, newToast] }))
    
    // Auto remove after 5 seconds
    setTimeout(() => {
      setState(prev => ({ toasts: prev.toasts.filter(t => t.id !== id) }))
    }, 5000)
    
    return {
      id,
      dismiss: () => setState(prev => ({ toasts: prev.toasts.filter(t => t.id !== id) }))
    }
  }, [])

  const dismiss = React.useCallback((toastId?: string) => {
    setState(prev => ({ 
      toasts: toastId ? prev.toasts.filter(t => t.id !== toastId) : [] 
    }))
  }, [])

  return {
    toasts: state.toasts,
    toast,
    dismiss
  }
}

export { useToast }
